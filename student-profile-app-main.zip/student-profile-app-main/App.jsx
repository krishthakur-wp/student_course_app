import { useState } from 'react'
import './index.css'

// List of courses shown in the dropdown.
// Kept as a plain array so it's easy to edit for a viva/demo.
const COURSES = [
  'B.Tech Computer Science',
  'B.Tech Information Technology',
  'B.Sc Computer Science',
  'BCA',
  'MCA',
  'M.Tech Computer Science',
]

function App() {
  // ---- Controlled form state (Requirement 1 & 3) ----
  // A single object holds all three fields so we can update
  // them with one generic handler.
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    course: '',
  })

  // Holds the student details AFTER the form has been submitted.
  // Starts as null so nothing is shown until the user registers.
  const [submittedData, setSubmittedData] = useState(null)

  // ---- Generic change handler for every controlled input ----
  // (Requirement 4: controlled components using value + onChange)
  const handleChange = (event) => {
    const { name, value } = event.target
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }))
  }

  // ---- Submit handler ----
  const handleSubmit = (event) => {
    event.preventDefault() // Requirement 8: prevent page reload

    // Save a snapshot of the current form data to display below.
    setSubmittedData(formData)
  }

  return (
    <div className="page">
      <div className="form-shell">
        <header className="form-header">
          <span className="eyebrow">College Practical · React</span>
          <h1>Student Registration Form</h1>
          <p>Fill in the details below to register a new student record.</p>
        </header>

        <form className="card" onSubmit={handleSubmit} noValidate={false}>
          {/* Name field */}
          <div className="field">
            <label htmlFor="name">
              Name<span className="required">*</span>
            </label>
            <input
              id="name"
              type="text"
              name="name"
              placeholder="Enter your name"
              value={formData.name}
              onChange={handleChange}
              required
              minLength={2}
            />
          </div>

          {/* Email field */}
          <div className="field">
            <label htmlFor="email">
              Email<span className="required">*</span>
            </label>
            <input
              id="email"
              type="email"
              name="email"
              placeholder="Enter your email"
              value={formData.email}
              onChange={handleChange}
              required
            />
          </div>

          {/* Course field */}
          <div className="field">
            <label htmlFor="course">
              Course<span className="required">*</span>
            </label>
            <select
              id="course"
              name="course"
              value={formData.course}
              onChange={handleChange}
              required
            >
              <option value="" disabled>
                Select Course
              </option>
              {COURSES.map((course) => (
                <option key={course} value={course}>
                  {course}
                </option>
              ))}
            </select>
          </div>

          <button type="submit" className="submit-btn">
            Register
          </button>
        </form>

        {/* Submitted details are only rendered once the form has
            been submitted at least once. */}
        {submittedData && (
          <section className="result-card">
            <h2>Submitted Student Details</h2>
            <div className="result-row">
              <span className="result-label">Name</span>
              <span className="result-value">{submittedData.name}</span>
            </div>
            <div className="result-row">
              <span className="result-label">Email</span>
              <span className="result-value">{submittedData.email}</span>
            </div>
            <div className="result-row">
              <span className="result-label">Course</span>
              <span className="result-value">{submittedData.course}</span>
            </div>
          </section>
        )}
      </div>
    </div>
  )
}

export default App
