# Student Profile App

A simple React (Vite + JavaScript) application built for the practical assignment on **React Components and Props**.

## 📋 Practical Question 1: React Component and Props

**Task:** Create a React application for a Student Profile.

**Requirements met:**
1. ✅ A functional component called `Student` (`src/components/Student.jsx`).
2. ✅ `name`, `course`, and `college` are passed to `Student` using props.
3. ✅ The received information is displayed using JSX.
4. ✅ Two (in fact, three) `Student` components are created and rendered from the `App` component.

## 🛠️ Tech Stack

- React 18
- Vite 5
- Plain JavaScript / JSX (no TypeScript)
- Plain CSS (no external UI libraries)

## 📁 Project Structure

```
student-profile-app/
├── index.html
├── package.json
├── vite.config.js
├── .gitignore
├── README.md
└── src/
    ├── main.jsx          # React entry point
    ├── App.jsx           # Renders multiple Student components
    ├── App.css           # Layout & heading styling
    ├── index.css          # Global styles
    └── components/
        ├── Student.jsx    # Reusable functional component (props)
        └── Student.css    # Card styling
```

## ▶️ How to Run Locally

Make sure you have [Node.js](https://nodejs.org/) (v16 or later) installed.

```bash
# 1. Install dependencies
npm install

# 2. Start the development server
npm run dev
```

Then open the URL shown in the terminal (usually `http://localhost:5173`) in your browser.

### Other useful commands

```bash
# Build for production
npm run build

# Preview the production build
npm run preview
```

## 🚀 How to Upload to GitHub

```bash
# 1. Initialize git (if not already done)
git init

# 2. Add all files
git add .

# 3. Commit
git commit -m "Initial commit: Student Profile React app"

# 4. Create a new repository on GitHub (via github.com), then link it
git remote add origin https://github.com/<your-username>/<your-repo-name>.git

# 5. Push
git branch -M main
git push -u origin main
```

## ✅ Requirement Checklist

| # | Requirement | Status |
|---|-------------|--------|
| 1 | Functional component `Student` | ✅ Done |
| 2 | Props: `name`, `course`, `college` | ✅ Done |
| 3 | Info displayed using JSX | ✅ Done |
| 4 | At least 2 `Student` components rendered from `App` | ✅ Done (3 rendered) |
| 5 | Built with React + Vite | ✅ Done |
| 6 | JavaScript/JSX, not TypeScript | ✅ Done |
| 7 | Clean, professional, beginner-friendly | ✅ Done |
| 8 | Simple CSS styling | ✅ Done |
| 9 | No unnecessary libraries | ✅ Done (only react, react-dom, vite) |
| 10 | Runs without errors | ✅ Verified with `npm run build` |
