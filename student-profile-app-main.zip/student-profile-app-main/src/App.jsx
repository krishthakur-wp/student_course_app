import Student from './components/Student.jsx'
import './App.css'

function App() {
  return (
    <div className="app-container">
      <header className="app-header">
        <h1>Student Profile</h1>
        <p className="app-subtitle">React Practical - Components and Props</p>
      </header>

      <main className="student-list">
        <Student
          name="Ananya Sharma"
          course="B.Tech Computer Science"
          college="Indian Institute of Technology, Bhubaneswar"
        />
        <Student
          name="Rohan Mehta"
          course="B.Sc Information Technology"
          college="KIIT University"
        />
        <Student
          name="Priya Nair"
          course="BCA - Bachelor of Computer Applications"
          college="Utkal University"
        />
      </main>

      <footer className="app-footer">
        <p>Built with React + Vite</p>
      </footer>
    </div>
  )
}

export default App
