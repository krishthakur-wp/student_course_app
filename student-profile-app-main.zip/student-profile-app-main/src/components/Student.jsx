import './Student.css'

// Functional component that receives student details via props
function Student(props) {
  const { name, course, college } = props

  return (
    <div className="student-card">
      <div className="student-avatar">{name.charAt(0)}</div>
      <h2 className="student-name">{name}</h2>
      <p className="student-detail">
        <span className="label">Course:</span> {course}
      </p>
      <p className="student-detail">
        <span className="label">College:</span> {college}
      </p>
    </div>
  )
}

export default Student
